


from captcha.audio import AudioCaptcha
from captcha.image import ImageCaptcha

image = ImageCaptcha(fonts=['/path/A.ttf', '/path/B.ttf'])

data = image.generate('1234')
image.write('1234', 'out.png')






"""
import urllib.request
import json

_access_token="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"
headers={'Authorization':"Token"+_access_token}

url="https://api.github.com/users/Rajkumar-V/repos"

req=urllib.request.Request(url,headers=headers,method="GET")

with urllib.request.urlopen(req) as resp:
    data = (resp.read().decode("utf-8"))
    data = json.loads(data)

for i in range(0, len(data)):
    resp = data[i]
    print(resp["name"])

"""