# Dont import urllib here
import json
import os
import pytest

from libCore.http_interface import *
from libCore.log_provider import *
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
print("BASE_DIR",BASE_DIR)

# RootDir = os.path.dirname(os.path.dirname(__file__))
# print(os.path.dirname())
# print("RootDir",RootDir)
# RootDirectory = RootDir.replace('\\','\\\\')

with open('/home/rajkumar/RestTroth-main/Config/user_info.json') as f:
    data = json.load(f)

    print(data['User1']['_owner'])
    print(data["User1"]['_access_token'])

# _owner = "Rajkumar-V"
# _access_token = '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'

class Connect:
    def __init__(self):
        self.data = self.get_auth_from_config()
        self.g_headers = {'Authorization': "Token " + self.data["User1"]['_access_token'] ,
                          'Content-Type': "application/json"}

    def get_auth_from_config(self):
        try:
            # path = "../../Config/user_info.json"
            # path = "G:/RestAPIFramework/Config/user_info.json"
            # print("Base_DIR",Base_DIR)
            # path = os.path.join(Base_DIR, 'Config', 'user_info.json')
            path = BASE_DIR+"/Config/user_info.json"
            print("json_file,", path)
            if os.path.exists(path):
                with open(path,"r+") as f:
                    data = json.load(f)
                    print("file exists")
                    #print(data)
            else:
                raise Exception("FILE NOT FOUND")
            return data
        except Exception as e:
            Logger.log_error("unable to find the path {}".format(str(e)))

    def get_all_repos(self):
        try:
            url = f"https://api.github.com/users/{self.data['User1']['_owner']}/repos"
            response = get_resource(url, self.g_headers)
            #print(response)
            repos = [dict_repo["name"] for dict_repo in response]
            Logger.log_info("getting all repos as expected ");
            return repos
        except Exception as e:
            Logger.log_error("unable to get the repos {}".format(str(e)))

    def is_repo_name_exist(self, repo_name):
        try:
            repos = self.get_all_repos()
            #print(repos)
            if repo_name in repos:
                Logger.log_info("repo name is existed in the response")
                return True
            else:
                Logger.log_info("repo name doesn't exist in the list")
                return False
        except Exception as e:
            Logger.log_error("unable to locate the repo name from existing response{}".format(str(e)))

    def get_all_collaborators(self):
        try:
            url = f"https://api.github.com/repos/{self.data['User1']['_owner']}/RohithMission20/collaborators"
            response = get_resource(url, self.g_headers)
            #print(response)
            repos = [dict_repo["login"] for dict_repo in response]
            Logger.log_info("getting all collabortors form the given repo");
            return repos

        except Exception as e:
            Logger.log_error("unable to get the collaborators{}".format(str(e)))

    def add_collaborator(self, repo, user):
        try:
            url = f"https://api.github.com/repos/{self.data['User1']['_owner']}/{repo}/collaborators/{user}"
            response = create_resource(url=url, headers=self.g_headers, method="PUT")
            Logger.log_info("requested succesfully to add a collaborator");
            return response.code
        except Exception as e:
            Logger.log_error("getting issues to add a collaborator{}".format(str(e)))

    def delete_collaborator(self, repo ,user):
        try:
            url = f"https://api.github.com/repos/{self.data['User1']['_owner']}/{repo}/collaborators/{user}"
            response = delete_resourse ( url=url, headers=self.g_headers)
            Logger.log_info ( "requested succesfully to DELETE a collaborator" );
            return response.code
        except Exception as e:
            Logger.log_error ( "getting issues to DELETE a collaborator{}".format ( str ( e ) ) )

    def is_collaborator_name_exist(self, collaborator_name):
        try:
            repos = self.get_all_collaborators()
            #print(repos)
            if collaborator_name in repos:
                Logger.log_info("collaborator name is existed in the response")
                return True
            else:
                Logger.log_info("collaborator name doesn't exist in the list")
                return False
        except Exception as e:
            Logger.log_error("unable to locate the repo name from existing response{}".format(str(e)))


    def deleate_repo(self, repo_name):

        try:
            url = f"https://api.github.com/repos/{self.data['User1']['_owner']}/{repo_name}"
            response = delete_resourse(url, self.g_headers)
            Logger.log_info("sucessfully deleting a repo ")
            return response.code
        except Exception as e:
            Logger.log_error("unable to delete the repo{}".format(str(e)))

    def create_repo(self, value):
        try:
            value = value
            data = json.dumps(value).encode("utf-8")
            url = f"https://api.github.com/user/repos"
            response = create_resource(url=url, headers=self.g_headers, data=data)
            Logger.log_info("creating a repository succesfully");
            return response.code
        except Exception as e:
            raise Exception("Not able to create a repo{}".format(str(e)))


if __name__ == "__main__":
    c = Connect()
    #print(c.get_auth_from_config())  #yes

    print(c.get_all_collaborators())
    #print(c.add_collaborator('RohithMission20','Rampavan123'))    #201 created
    #print(c.delete_collaborator('RohithMission20','Rampavan123')) #204
    #print(c.is_collaborator_name_exist('Rampavan123'))  #204 no content


    print(c.get_all_repos()) #yes
    #result = c.create_repo(value={"name": "Code_Error"})
    #print(result)

    #result = c.deleate_repo('code_error')  #Noresult
    #print(c.is_repo_name_exist('RohithMission20')) #yes





