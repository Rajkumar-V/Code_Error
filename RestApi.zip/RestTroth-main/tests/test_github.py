from source.git_hub.git_connect import Connect
from libCore.assertions import *


class TestCases:

    @pytest.fixture()
    def c (self):
        return Connect()

    @pytest.mark.skip
    def test_repo_exists(self, c):
        resp = c.is_repo_name_exist('RohithMission20')
        assert_true(resp == True, "getting repo name exists")
        print("true")

    @pytest.mark.skip
    def test_collaborators_exists(self, c):
        resp = c.is_collaborator_name_exist('Rampavan123')
        assert_true(resp == True, "getting collaborator name exists")
        print("true")

    @pytest.mark.skip
    def test_create_repo(self, c):
        data = c.create_repo(value={"name": "sample"})
        assert_equal(exp=201, act=data)
        print("true")

    @pytest.mark.skip
    def test_deleate_repo(self, c):
        c.deleate_repo('sample')
        resp = c.is_repo_name_exist('sample')
        assert_false(resp, "deleting and checking the repo")
        print("true")

    @pytest.mark.skip
    def test_get_collaborators(self, c):
        expeced = ['Rajkumar-V','Rampavan123']
        data = c.get_all_collaborators()
        assert_true(data == expeced, "getting collaborators as expected")
        print("true")

    @pytest.mark.skip
    def test_add_collaborators(self, c):
        data = c.add_collaborator('RohithMission20', 'Rampavan123')
        assert_equal(exp=201, act=data)
        print("true")


    # @pytest.mark.skip
    def test_delete_collaborators(self, c):
        c.delete_collaborator ('RohithMission20', 'Rampavan123')
        resp = c.is_collaborator_name_exist ( 'Rampavan123' )
        assert_false ( resp, "deleting and checking the repo" )
        print ( "true" )


