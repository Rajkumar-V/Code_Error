import argparse
import pytest

parser = argparse.ArgumentParser ( )

parser.add_argument("-n1", "--number1", type=int,  help="first number")
parser.add_argument("-n2" , "--number2", type=int, help="second number")
args = parser.parse_args()

a=args.number1
b=args.number2

def add(a, b):
    return a+b

def product(a, b):
    return a*b


# @pytest.fixture
# def params(request):
#     params = {}
#     params['number1'] = request.config.getoption('--number1')
#     params['number2'] = request.config.getoption('--number2')
#     if params['number1'] is None or params['number2'] is None:
#         pytest.skip()
#     return params

