
def add(a, b):
    return a+b

def product(a, b):
    return a*b
