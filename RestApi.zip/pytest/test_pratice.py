import conftest
import pytest

def test_add(a, b):
    assert conftest.add ( [a],[b] ) == 10

def test_product(a,b):
    assert conftest.product(a, b) == 25

