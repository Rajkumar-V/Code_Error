import conftest
import pytest
import sys

#@pytest.mark.skip(reason = "just for fun")
#@pytest.mark.number
def test_add():
    assert conftest.add ( 7, 3 ) == 10
    assert conftest.add ( 7 ) == 9


#@pytest.mark.number
def test_product():
    assert conftest.product ( 5, 5 ) == 25
    assert conftest.product ( 5 ) == 10
    print ( conftest.product ( 7, 3 ) )


#@pytest.mark.strings
def test_add_strings():
    result = conftest.add ( "hello", "world" )
    assert result == "helloworld"
    assert type ( result ) is str
    assert "hello" in result


#@pytest.mark.strings
def test_product_strings():
    assert conftest.product ( "hello", 3 ) == "hellohellohello"
    result = conftest.product ( "hello" )
    assert result == "hellohello"


